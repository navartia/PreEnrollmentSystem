﻿namespace PreEnrollmentSystem {
    
    
    public partial class EnrollmentDataSet {
    }
}


namespace PreEnrollmentSystem.EnrollmentDataSetTableAdapters {
    
    
    public partial class CourseScheduleViewTableAdapter {
    }
}
